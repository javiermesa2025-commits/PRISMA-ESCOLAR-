# Prisma Escolar — versión estática para Google Sites

## Qué contiene
`prisma-escolar-google-sites.html` es un único archivo autocontenido:
- Todo el HTML, CSS y JavaScript en un solo archivo.
- Las imágenes (escudo del colegio, íconos) van incrustadas como datos (no hay carpetas de imágenes que subir aparte).
- No usa React, Node.js, build tools ni paquetes: es HTML/CSS/JS puro, compatible con cualquier navegador.
- Única conexión externa: la tipografía de Google Fonts (Big Shoulders Display y Work Sans). Si el sitio necesita funcionar 100% offline, dímelo y la incrusto también.
- Los botones "✎ Editar" que veías en el chat no aparecerán aquí: solo se activan dentro de Claude para ti como propietaria. En Google Sites el sitio se mostrará siempre en modo lectura, igual que lo ve cualquier visitante hoy.

## Opción A — Insertar como "Insertar código" (recomendado, mantiene todo interactivo)
Google Sites permite pegar HTML/CSS/JS directamente si usas la opción de insertar código embebido:
1. Abre tu sitio en sites.google.com y entra al modo de edición.
2. Ve a **Insertar → Insertar código** (o "Embed" → "Embed code" en inglés).
3. Abre `prisma-escolar-google-sites.html` con un editor de texto, copia **todo** el contenido y pégalo en el cuadro que aparece.
4. Guarda e inserta. Ajusta el tamaño del bloque para que la página se vea completa (alto recomendado: 100% o "pantalla completa" si tu plantilla lo permite).

Si tu cuenta de Google Sites no muestra "Insertar código" (algunas cuentas educativas lo restringen), usa la Opción B.

## Opción B — Alojarlo aparte e insertarlo por URL
1. Sube `prisma-escolar-google-sites.html` a Google Drive, GitHub Pages, Netlify o cualquier hosting estático, y hazlo público.
2. Copia la URL pública del archivo.
3. En Google Sites: **Insertar → Insertar → Por URL**, pega el enlace.

## Si más adelante quieres seguir editando
El sitio "maestro" y editable sigue siendo el enlace de Claude que ya conoces (https://claude.ai/artifact/6Hhg6BK6aoLffR7x6yGzEF). Cuando hagas cambios ahí (objetivos, proyectos, donaciones, etc.), vuelve a pedirme "expórtame la versión para Google Sites" y te genero un `prisma-escolar-google-sites.html` actualizado para reemplazar el que ya insertaste.
